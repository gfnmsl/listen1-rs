use mods::process::process;

fn main() {
    process();
}