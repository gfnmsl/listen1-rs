/*
    存放 文本框 实例 的 模块 
*/ 

use gtk4::{Entry};// 文本框模块 

// 右侧 菜单栏 搜索 文本框 
pub fn right_search(name: &str) -> Entry {
    // 创建 文本框 实例 
    let search_entry = crate::entry_attr::entry_search(&name);

    // 返回 文本框 实例 
    search_entry
}