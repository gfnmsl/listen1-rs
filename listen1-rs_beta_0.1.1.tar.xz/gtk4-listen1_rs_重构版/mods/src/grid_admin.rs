/*
    存放 所有 grid 布局 的 模块 
*/ 
use gtk4::Grid;

// 主窗口 父容器 grid 
pub fn grid_admin_docker() -> Grid {
    // 创建 grid 布局 实例 
    let grid = crate::grid_attr::grid_docker();

    // 返回 grid 布局 实例 
    grid
}

// 左侧 选项栏 grid 
pub fn grid_admin_docker_left_option() -> Grid {
    // 创建 grid 布局 实例 
    let grid = crate::grid_attr::grid_option();

    // 返回 grid 布局 实例 
    grid
}

// 右侧 菜单栏 grid 
pub fn grid_admin_docker_right_menu() -> Grid {
    // 创建 grid 布局 实例 
    let grid = crate::grid_attr::grid_menu();

    // 返回 grid 布局 实例 
    grid
}