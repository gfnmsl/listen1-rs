/*
    activate(激活) 模块的实现
*/ 

// 引入必要的库
use gtk4::prelude::*;// gtk4 核心模块
use gtk4::{Application,ApplicationWindow};// gtk4 应用模块
use gtk4::CssProvider;
use gtk4::prelude;
use gtk4::STYLE_PROVIDER_PRIORITY_APPLICATION;
use gtk4::style_context_add_provider_for_display;

pub fn activate(app: &Application) -> ApplicationWindow {
    // 创建无属性窗口
    let window = ApplicationWindow::new(app);

    // 设置窗口属性
    window.set_title(Some("listen1-rust"));// 设置窗口标题
    window.set_default_size(1100,800 );// 设置窗口默认大小




    
    // 创建 grid 布局 并 添加 到 窗口
    let docker = crate::grid_admin::grid_admin_docker();// 窗口 父容器
    window.set_child(Some(&docker));

    let docker_left_option = crate::grid_admin::grid_admin_docker_left_option();// 左侧 选项栏
    docker.attach(&docker_left_option,0,0,1,1);// 左侧 选项栏 加入 父容器

    let docker_right_menu = crate::grid_admin::grid_admin_docker_right_menu(); // 右侧 菜单栏
    docker.attach_next_to(&docker_right_menu,Some(&docker_left_option),gtk4::PositionType::Right,1,1); // 右侧 菜单栏 加入 父容器





    // 创建 左侧 选项栏 按钮 
    let _button_ps = crate::button_admin::off_button("平台选择");

    let _button_wangyi = crate::button_admin::left_option_button("网易云音乐");

    let _button_qq = crate::button_admin::left_option_button("QQ音乐");

    let _button_kugo = crate::button_admin::left_option_button("酷狗音乐");

    let _button_kuwo = crate::button_admin::left_option_button("酷我音乐");

    let _button_migu = crate::button_admin::left_option_button("咪咕音乐");

    let _button_qianqian = crate::button_admin::left_option_button("千千音乐");

    let _button_bilibili = crate::button_admin::left_option_button("哔哩哔哩");

    let _button_bendi = crate::button_admin::off_button("本地播放");

    let _button_zidingyigedan = crate::button_admin::left_option_button("自定义歌单");

    let _button_bendishipin = crate::button_admin::left_option_button("本地视频");

    let _button_bendiyinpin = crate::button_admin::left_option_button("本地音频");





    // 将 左侧 选项栏 按钮 加入 左侧 选项栏
    docker_left_option.attach(&_button_ps,0,0,1,1);// 将 平台选择 按钮 加入 左侧 选项栏

    docker_left_option.attach_next_to(&_button_wangyi,Some(&_button_ps),gtk4::PositionType::Bottom,1,1);// 将 网易云音乐 按钮 放在 平台选择 按钮 下方

    docker_left_option.attach_next_to(&_button_qq,Some(&_button_wangyi),gtk4::PositionType::Bottom,1,1);// 将 QQ音乐 按钮 放在 网易云音乐 按钮 下方

    docker_left_option.attach_next_to(&_button_kugo,Some(&_button_qq),gtk4::PositionType::Bottom,1,1);// 将 酷狗音乐 按钮 放在 QQ音乐 按钮 下方

    docker_left_option.attach_next_to(&_button_kuwo,Some(&_button_kugo),gtk4::PositionType::Bottom,1,1);// 将 酷我音乐 按钮 放在 酷狗音乐 按钮 下方

    docker_left_option.attach_next_to(&_button_migu,Some(&_button_kuwo),gtk4::PositionType::Bottom,1,1);// 将 咪咕音乐 按钮 放在 酷我音乐 按钮 下方

    docker_left_option.attach_next_to(&_button_qianqian,Some(&_button_migu),gtk4::PositionType::Bottom,1,1);// 将 千千音乐 按钮 放在 咪咕音乐 按钮 下方

    docker_left_option.attach_next_to(&_button_bilibili,Some(&_button_qianqian),gtk4::PositionType::Bottom,1,1);// 将 哔哩哔哩 按钮 放在 千千音乐 按钮 下方

    docker_left_option.attach_next_to(&_button_bendi,Some(&_button_bilibili),gtk4::PositionType::Bottom,1,1);// 将 本地播放 按钮 放在 哔哩哔哩 按钮 下方

    docker_left_option.attach_next_to(&_button_zidingyigedan,Some(&_button_bendi),gtk4::PositionType::Bottom,1,1);// 将 自定义歌单 按钮 放在 本地播放 按钮 下方

    docker_left_option.attach_next_to(&_button_bendishipin,Some(&_button_zidingyigedan),gtk4::PositionType::Bottom,1,1);// 将 本地视频 按钮 放在 自定义歌单 按钮 下方

    docker_left_option.attach_next_to(&_button_bendiyinpin,Some(&_button_bendishipin),gtk4::PositionType::Bottom,1,1);// 将 本地音频 按钮 放在 本地视频 按钮 下方   

   


    // 创建 右侧 菜单栏 按钮
    let _button_left_tog = crate::button_admin::right_menu_button("<");
    let _button_right_tog = crate::button_admin::right_menu_button(">");
    let _entry_search = crate::entry_admin::right_search("搜索");
    let _button_user = crate::button_admin::right_menu_button("账号");
    let _button_setting = crate::button_admin::right_menu_button("设置");
    let _button_tog_background = crate::button_admin::right_menu_button("切换后台");
    let _button_window_tog = crate::button_admin::right_menu_button("全屏窗口切换");
    let _button_quit = crate::button_admin::right_menu_button("退出");




    // 将 右侧 菜单栏 按钮 加入 右侧 菜单栏
    docker_right_menu.attach(&_button_left_tog,0,0,1,1);// 将 左侧 按钮 加入 右侧 菜单栏

    docker_right_menu.attach_next_to(&_button_right_tog,Some(&_button_left_tog),gtk4::PositionType::Right,1,1);// 将 右侧 放在 左侧 按钮 右侧

    docker_right_menu.attach_next_to(&_entry_search,Some(&_button_right_tog),gtk4::PositionType::Right,1,1);// 将 搜索 按钮 加入 右侧 菜单栏

    docker_right_menu.attach_next_to(&_button_user,Some(&_entry_search),gtk4::PositionType::Right,1,1);// 将 账号 按钮 加入 右侧 菜单栏

    docker_right_menu.attach_next_to(&_button_setting,Some(&_button_user),gtk4::PositionType::Right,1,1);// 将 设置 按钮 加入 右侧 菜单栏

    docker_right_menu.attach_next_to(&_button_tog_background,Some(&_button_setting),gtk4::PositionType::Right,1,1);// 将 切换后台 按钮 加入 右侧 菜单栏

    docker_right_menu.attach_next_to(&_button_window_tog,Some(&_button_tog_background),gtk4::PositionType::Right,1,1);// 将 全屏窗口切换 按钮 加入 右侧 菜单栏

    docker_right_menu.attach_next_to(&_button_quit,Some(&_button_window_tog),gtk4::PositionType::Right,1,1);// 将 退出 按钮 加入 右侧 菜单栏





    // 引入 css 样式文件
   let provider_bei_jing = CssProvider::new();// 创建 背景 css 提供者

    provider_bei_jing.load_from_data(include_str!("css/bei_jing.css"));// 引入 背景 css 文件
    
    let provider_an_niu = CssProvider::new();// 创建 按钮 css 提供者

    provider_an_niu.load_from_data(include_str!("css/an_niu.css"));// 引入 按钮 css 文件

    let provider_an_niu_biao_qian = CssProvider::new();// 创建 按钮标签 css 提供者

    provider_an_niu_biao_qian.load_from_data(include_str!("css/an_niu_biao_qian.css"));// 引入 按钮标签 css 文件

    let provider_wen_ben_kuang = CssProvider::new();// 创建 文字框 css 提供者

    provider_wen_ben_kuang.load_from_data(include_str!("css/wen_ben_kuang.css"));// 引入 文字框 css 文件





    // 添加 CSS 提供者 到 窗口 
    style_context_add_provider_for_display(// 添加 背景 css 提供者 到 窗口 
        &prelude::WidgetExt::display(&window),
        &provider_bei_jing,
        STYLE_PROVIDER_PRIORITY_APPLICATION,
    );
    
    style_context_add_provider_for_display(// 添加 按钮 css 提供者 到 窗口 
        &prelude::WidgetExt::display(&window),
        &provider_an_niu,
        STYLE_PROVIDER_PRIORITY_APPLICATION,
    );

    style_context_add_provider_for_display(// 添加 按钮标签 css 提供者 到 窗口 
        &prelude::WidgetExt::display(&window),
        &provider_an_niu_biao_qian,
        STYLE_PROVIDER_PRIORITY_APPLICATION,
    );

    style_context_add_provider_for_display(// 添加 文字框 css 提供者 到 窗口 
        &prelude::WidgetExt::display(&window),
        &provider_wen_ben_kuang,
        STYLE_PROVIDER_PRIORITY_APPLICATION,
    );
    



    // 事件处理区域( .clone() 是 克隆 )

    // 按钮 点击 新建 窗口 
   _button_setting.connect_clicked(crate::button_event::universal_new_window(app.clone(), "设置"));
    _button_wangyi.connect_clicked(crate::button_event::universal_new_window(app.clone(), "网易云音乐"));
    _button_qq.connect_clicked(crate::button_event::universal_new_window(app.clone(), "QQ音乐"));
    _button_kugo.connect_clicked(crate::button_event::universal_new_window(app.clone(), "酷狗音乐"));
    _button_kuwo.connect_clicked(crate::button_event::universal_new_window(app.clone(), "酷我音乐"));
    _button_migu.connect_clicked(crate::button_event::universal_new_window(app.clone(), "咪咕音乐"));
    _button_qianqian.connect_clicked(crate::button_event::universal_new_window(app.clone(), "千千音乐"));
    _button_bilibili.connect_clicked(crate::button_event::universal_new_window(app.clone(), "哔哩哔哩"));
    _button_zidingyigedan.connect_clicked(crate::button_event::universal_new_window(app.clone(), "自定义歌单"));
    _button_bendishipin.connect_clicked(crate::button_event::universal_new_window(app.clone(), "本地视频"));
    _button_bendiyinpin.connect_clicked(crate::button_event::universal_new_window(app.clone(), "本地音频"));
    _button_user.connect_clicked(crate::button_event::universal_new_window(app.clone(), "账号"));

    // 按钮点击 全屏/窗口 切换
    _button_window_tog.connect_clicked(crate::button_event::universal_tog_window(window.clone()));

    // 按钮点击 退出 
    _button_quit.connect_clicked(crate::button_event::universal_exit_window(window.clone()));

    // 按钮点击 切换后台
    _button_tog_background.connect_clicked(crate::button_event::universal_cut_window(window.clone()));




    // 返回窗口
    window
}