/* 
    存放 所有 grid布局属性 的 模块 
*/

// 导入必要的库
use gtk4::Grid;
use gtk4::prelude::GridExt;
use gtk4::BaselinePosition;
use gtk4::Align;
use gtk4::prelude::WidgetExt;

// 定义 grid 属性 模板
pub fn grid() -> Grid {
    // 创建 Grid 布局实例
    let grid = Grid::new();

    // 设置 Grid 布局的属性

    // 设置 grid 宽高
    grid.set_size_request(1100, 800); // 设置 Grid 布局的宽高

    // 行列间距
    grid.set_row_spacing(10); // 设置 Grid 布局的行间距

    grid.set_column_spacing(10); // 设置 Grid 布局的列间距

    // 行列等宽等高
    grid.set_row_homogeneous(true); // 设置 Grid 布局的行等宽

    grid.set_column_homogeneous(true); // 设置 Grid 布局的列等高
    
    // 组件布局 在 activate 模块中实现

    // 组件对其
    grid.set_row_baseline_position(0,BaselinePosition::Top); // 设置 第 0 行的基线对齐方式为顶部对齐

    // 组件边距
    grid.set_margin_top(10); // 设置 顶部边距 为 10px
    grid.set_margin_bottom(10); // 设置 底部边距 为 10px
    grid.set_margin_start(10); // 设置 左侧边距 为 10px
    grid.set_margin_end(10); // 设置 右侧边距 为 10px

    // 组件扩展
    grid.set_hexpand(true); // 设置 组件 的 水平扩展
    grid.set_vexpand(true); // 设置 组件 的 垂直扩展

    // grid 布局位置
    grid.set_halign(Align::Start); // 水平对齐位置 (Start End Center ; 左 右 中)
    grid.set_valign(Align::Start); // 垂直对齐位置 (Start End Center ; 上 下 中)
    /*
        将 Align 的 跟随属性改为 End 即可 实现 (水平 右 对齐 ; 垂直 下 对齐)
    */ 

    // 返回 Grid 布局实例
    grid
}

// 主窗口 父容器 grid 属性
pub fn grid_docker() -> Grid {
    // 创建 实例 继承 grid 模板 属性
    let grid = grid();

    // 按需设置 grid 属性
    grid.set_row_spacing(10); // 设置 Grid 布局的行间距

    grid.set_column_spacing(10); // 设置 Grid 布局的列间距

    grid.set_row_homogeneous(false); // 设置 Grid 布局的行等宽

    grid.set_column_homogeneous(false); // 设置 Grid 布局的列等高

    grid.set_hexpand(false); // 设置 组件 的水平扩展

    grid.set_vexpand(false); // 设置 组件 的垂直扩展

    grid.set_halign(Align::Start); // 水平对齐位置 (Start End Center ; 左 右 中)

    grid.set_valign(Align::Start); // 垂直对齐位置 (Start End Center ; 上 下 中)

    // 返回 Grid 布局实例
    grid
}

// 左侧 选项栏 grid 属性
pub fn grid_option() -> Grid {
    // 创建 实例 继承 父容器 grid 属性
    let grid = grid_docker();

    // 按需设置 grid 属性
    grid.set_size_request(200, 800); // 设置 Grid 布局的宽高

    grid.set_halign(Align::Center); // 水平对齐位置 (Start End Center ; 左 右 中)

    // 返回 grid 实例
    grid
}

// 右侧 菜单栏 grid 属性
pub fn grid_menu() -> Grid {
    // 创建 实例 继承 左侧 选项栏 grid 属性
    let grid = grid_option();

    // 按需设置 grid 属性
    grid.set_size_request(900, 800); // 设置 Grid 布局的宽高

    grid.set_halign(Align::Start); // 水平对齐位置 (Start End Center ; 左 右 中)

     grid.set_row_homogeneous(false); // 设置 Grid 布局的行等宽

    grid.set_column_homogeneous(false); // 设置 Grid 布局的列等高
    
    grid.set_row_homogeneous(false); // 设置 Grid 布局的行等宽

    // 返回 grid 实例
    grid
}
