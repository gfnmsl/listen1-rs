/*
    本模块用于 存放 按钮 的 事件处理
*/

// 引入 必要的 依赖
use gtk4::{Application, ApplicationWindow, Button};
use gtk4::prelude::*;

    // 按钮点击 新建窗口 (通用)
    pub fn universal_new_window(app: Application, title: &'static str) -> impl Fn(&Button) {
        move |_| {
            let new_window = ApplicationWindow::new(&app);
            new_window.set_title(Some(title));
            new_window.set_default_size(900, 600);
            new_window.present();
        }
    }

    // 按钮点击 全屏/窗口 (通用)
    pub fn universal_tog_window(window: ApplicationWindow) -> impl Fn(&Button) {
        move |_| {
            if window.is_fullscreen() {
                window.unfullscreen();
            } else {
                window.fullscreen();
            }
        }
    }

    // 按钮点击 退出 (通用)
    pub fn universal_exit_window(window: ApplicationWindow) -> impl Fn(&Button) {
        move |_| {
            window.close();
        }
    }

    // 按钮点击 窗口切换后台 (通用)
    pub fn universal_cut_window(window: ApplicationWindow) -> impl Fn(&Button) {
        move |_| {
            window.hide();
        }
    }