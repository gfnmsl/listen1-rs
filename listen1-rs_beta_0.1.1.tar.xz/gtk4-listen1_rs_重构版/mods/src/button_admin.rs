/*
    存放 按钮 实例 的 模块
*/ 

use gtk4::{Button};// gtk4 一系列 ui 模块

// 左侧 选项栏 按钮 实例
pub fn left_option_button(name: &str) -> Button {
    // 创建 按钮 实例
    let button = crate::button_attr::button_option(&name);

    // 返回 按钮 实例
    button
}

// 右侧 菜单栏 按钮 实例
pub fn right_menu_button(name: &str) -> Button {
    // 创建 按钮 实例
    let button = crate::button_attr::button_menu(&name);

    // 返回 按钮 实例
    button
}

// 不可 点击 按钮 实例
pub fn off_button(name: &str) -> Button {
    // 创建 按钮 实例
    let button = crate::button_attr::button_off(&name);

    // 返回 按钮 实例
    button
}