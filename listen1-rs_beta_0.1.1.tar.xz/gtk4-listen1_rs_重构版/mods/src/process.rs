/*
    process(流程) 模块的实现
*/ 

// 引入必要的库
use gtk4::prelude::*;// gtk4 核心模块
use gtk4::Application;// gtk4 应用模块

// 定义 Process 方法
pub fn process() {
    // 创建 程序 实例
    let app = Application::new(Some("com.example.calculator"), Default::default());

    // 连接 activate 信号(程序激活后进行的操作)
    app.connect_activate(|app| {
        let window = crate::activate::activate(app);// 调用 自定义 方法
        window.present();// 显示窗口(新版 gtk4 的方法)
    });

    // 运行程序
    app.run();
}