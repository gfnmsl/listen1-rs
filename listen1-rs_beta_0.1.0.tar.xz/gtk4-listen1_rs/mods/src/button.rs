/*
    button_s(按钮) 模块 的 实现
*/ 

// 引入必要的 模块
use gtk4::prelude::*;// gtk4 核心模块
use gtk4::{Button, Align};// gtk4 一系列 ui 模块

// 按钮 方法 模板
pub fn button_s(name: &str) -> Button {
    let button_s = Button::new();
    button_s.set_hexpand(false);// 水平扩展选项(true 启用 false 禁用)
    button_s.set_vexpand(false);// 垂直扩展选项(true 启用 false 禁用)
    button_s.set_sensitive(true);// 启用按钮(true 启用 false 禁用)
    button_s.set_label(name);//  创建 或 更新 按钮 的 标签文本
    button_s.set_halign(Align::Center); // 按钮水平文本位置 (Start, End, Center ; 左 右 中) 
    button_s.set_valign(Align::Center); //  按钮垂直文本位置 (Start, End, Center ; 上 下 中) 
    // button_s.set_icon_name("gtk-dialog-warning");//  创建 或  更新 按钮 的 图标名称
    // button_s.set_size_request(50, 50);// 设置 按钮 的 宽高
    
    /*
        按钮方法的各个属性
        set_hexpand()           水平扩展 , 自动填充 存放 按钮 容器的 水平区域  , true 启用 false 禁用

        set_vexpand()           垂直扩展 , 自动填充 存放 按钮 容器的 垂直区域  , true 启用 false 禁用

        set_sensitive()         启用按钮 , 按钮是否可以点击 , true 启用 false 禁用

        set_label()                 更新 按钮 中 的 标签文本 , 会替换 原来的文本

        set_icon_name()     更新 按钮 中 的 图标名称 , 会替换 原来的图标 ，详细属性会在按钮方法下方展示

    */
    button_s// 返回 按钮 (返回了 你 设置的 按钮 属性)
}

// 顶部 菜单栏 组件
pub fn button_left (name: &str) -> Button {
    // 创建 实例 继承 button_s() 的 属性
    let button_s = button_s(name);

    // 按需设置 按钮 的 属性
    button_s.set_halign(Align::Center); // 按钮水平文本位置 (Start, End, Center ; 左 右 中) 
    button_s.set_valign(Align::End); //  按钮垂直文本位置 (Start, End, Center ; 上 下 中) 

    // 返回 按钮 
    button_s
}