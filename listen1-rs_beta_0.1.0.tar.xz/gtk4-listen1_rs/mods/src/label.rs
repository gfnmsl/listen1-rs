/*
    label_s(标签模块) 的具体实现
*/ 
use gtk4::{Label};// gtk4 标签模块

// 标签 方法
// 使用 Pango 标记语言的文本
pub fn label_pango(text: &str) -> Label {// 参数 text 用于自定义标签文本
    let label_pango = Label::new(Some(&format!("<b> {} </b>",text)));// 创建一个标签
    
    label_pango.set_use_markup(true);// 设置标签是否使用 Pango 标记语言

    // 返回标签
    label_pango
}