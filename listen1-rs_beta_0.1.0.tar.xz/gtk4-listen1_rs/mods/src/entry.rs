/*
    entry(文本框) 模块的具体实现
*/ 

// 引入必要的依赖
use gtk4::prelude::*;// gtk4 核心模块
use gtk4::{Entry};// 文本框模块 

// 文本框 方法 模板
pub fn entry_s(name: &str) -> Entry {
    // 创建文本框
    let entry = Entry::new();

    // 设置文本框的属性                                         
    entry.set_placeholder_text(Some(name));// 占为符 , 文本框 为空时显示的 文本

    entry.set_size_request(1200, 900);// 设置 文本框 的 宽高

    entry.set_max_length(10); // 限制 文本框 输入的 字符 最大 长度

    entry.set_visibility(false);// 文本框是否可见 , 设置为 false 文本框内的文字会被加密

    entry.set_editable(true);// 文本框是否可编辑 , 设置为 false 后文本框将无法编辑

    // 返回文本框
    entry
}
/*
    以上 文本框 属性 是 可写 在 模块 中的 , 并不全面 , 其余属性在 process.rs 中进行设置 
*/ 

// 文本框 (搜索框)
pub fn entry_search(name: &str) -> Entry {
    // 创建 实例 继承 entry_s() 的 属性
    let entry = entry_s(name);

    // 按需设置 文本框 的 属性
     entry.set_size_request(200, 25);// 设置 文本框 的 宽高

    entry.set_max_length(1000); // 限制 文本框 输入的 字符 最大 长度

    entry.set_visibility(true);// 文本框是否可见 , 设置为 false 文本框内的文字会被加密

    entry.set_editable(true);// 文本框是否可编辑 , 设置为 false 后文本框将无法编辑

    // 返回 实例
    entry
}