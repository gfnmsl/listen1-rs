/*
    activate(激活) 模块的实现
*/ 

// 引入必要的库
use gtk4::prelude::*;// gtk4 核心模块
use gtk4::{Application,ApplicationWindow,PositionType};// gtk4 应用模块
use gtk4::CssProvider;
use gtk4::prelude;
use gtk4::STYLE_PROVIDER_PRIORITY_APPLICATION;
use gtk4::style_context_add_provider_for_display;

pub fn activate(app: &Application) -> ApplicationWindow {
    // 创建无属性窗口
    let window = ApplicationWindow::new(app);

    // 设置窗口属性
    window.set_title(Some("listen-rs"));// 设置窗口标题
    window.set_default_size(1100,800 );// 设置窗口默认大小 
    window.set_resizable(true);// 设置窗口是否可变





    // 窗口 父容器
    let docker = crate::grid::grid_docker();

    // 选项栏(父容器 左侧)
    let _left_menu = crate::grid::grid_left_menu();

    // 菜单栏(父容器 右侧)
    let _right_menu = crate::grid::grid_right_menu();

    //  菜单栏 组件
    let button_left = crate::button::button_left("<");
    let button_right = crate::button::button_left(">");
    let search = crate::entry::entry_search("搜索");
    let _user = crate::button::button_left("账号");
    let _settings = crate::button::button_left("设置");
    let _background = crate::button::button_left("前后台切换");
    let _windows = crate::button::button_left("全屏窗口切换");
    let _exit = crate::button::button_left("退出");

    // 选项栏 选项
    let _label_name = crate::label::label_pango("平台选择");
    let _button_wangyi = crate::button::button_left("网易云音乐");
    let _button_qq = crate::button::button_left("QQ音乐");
    let _button_kugou = crate::button::button_left("酷狗音乐");
    let _button_kuwo = crate::button::button_left("酷我音乐");
    let _button_migu = crate::button::button_left("咪咕音乐");
    let _button_qianqian = crate::button::button_left("千千音乐");
    let _button_bilibili = crate::button::button_left("哔哩哔哩");
    let _label_name_0 = crate::label::label_pango("本地播放");
    let _button_gedan = crate::button::button_left("自定义歌单");
    let _button_local = crate::button::button_left("本地音频");
    let _button_play = crate::button::button_left("本地视频");




    
    // 将 父容器 添加到 窗口 中
    window.set_child(Some(&docker));

    // 将 左右 菜单栏 添加到 父容器 中
    docker.attach(&_left_menu, 0, 0, 1, 1);

    docker.attach_next_to(&_right_menu, Some(&_left_menu), PositionType::Right, 1, 1);// 将 (右侧 菜单栏) 放到 (左侧 菜单栏) 右侧
    
    // 将 菜单栏 组件 添加到 菜单栏 中
    _right_menu.attach(&button_left, 0, 0, 1, 1);

    _right_menu.attach_next_to(&button_right, Some(&button_left), PositionType::Right, 1, 1);// 将 (右侧 按钮) 放到 (左侧 按钮) 右侧

    _right_menu.attach_next_to(&search, Some(&button_right), PositionType::Right, 1, 1);// 将 (搜索框) 放到 (右侧 按钮) 右侧

    _right_menu.attach_next_to(&_user, Some(&search), PositionType::Right, 1, 1);// 将 (账号按钮) 放到 (搜索框) 右侧

    _right_menu.attach_next_to(&_settings, Some(&_user), PositionType::Right, 1, 1);// 将 (设置按钮) 放到 (账号按钮) 右侧

    _right_menu.attach_next_to(&_background, Some(&_settings), PositionType::Right, 1, 1);// 将 (前后台切换按钮) 放到 (设置按钮) 右侧

    _right_menu.attach_next_to(&_windows, Some(&_background), PositionType::Right, 1, 1);// 将 (全屏窗口切换按钮) 放到 (前后台切换按钮) 右侧

    _right_menu.attach_next_to(&_exit, Some(&_windows), PositionType::Right, 1, 1);// 将 (退出按钮) 放到 (全屏窗口切换按钮) 右侧





    // 将 选项 放进 选项栏 中
    _left_menu.attach(&_label_name, 0, 0, 1, 1);
    
    _left_menu.attach_next_to(&_button_wangyi, Some(&_label_name), PositionType::Bottom, 1, 1);// 将 (网易云音乐按钮) 放到 (平台选择) 下方

    _left_menu.attach_next_to(&_button_qq, Some(&_button_wangyi), PositionType::Bottom, 1, 1);// 将 (QQ音乐按钮) 放到 (网易云音乐按钮) 下方
    
    _left_menu.attach_next_to(&_button_kugou, Some(&_button_qq), PositionType::Bottom, 1, 1);// 将 (酷狗音乐按钮) 放到 (QQ音乐按钮) 下方

    _left_menu.attach_next_to(&_button_kuwo, Some(&_button_kugou), PositionType::Bottom, 1, 1);// 将 (酷我音乐按钮) 放到 (酷狗音乐按钮) 下方

    _left_menu.attach_next_to(&_button_migu, Some(&_button_kuwo), PositionType::Bottom, 1, 1);// 将 (咪咕音乐按钮) 放到 (酷我音乐按钮) 下方

    _left_menu.attach_next_to(&_button_qianqian, Some(&_button_migu), PositionType::Bottom, 1, 1);// 将 (千千音乐按钮) 放到 (咪咕音乐按钮) 下方

    _left_menu.attach_next_to(&_button_bilibili, Some(&_button_qianqian), PositionType::Bottom, 1, 1);// 将 (哔哩哔哩按钮) 放到 (千千音乐按钮) 下方+

    _left_menu.attach_next_to(&_label_name_0, Some(&_button_bilibili), PositionType::Bottom, 1, 1);// 将 (本地播放) 放到 (哔哩哔哩按钮) 下方

    _left_menu.attach_next_to(&_button_gedan, Some(&_label_name_0), PositionType::Bottom, 1, 1);// 将 (本地歌单按钮) 放到 (本地播放) 下方

    _left_menu.attach_next_to(&_button_local, Some(&_button_gedan), PositionType::Bottom, 1, 1);// 将 (本地音频按钮) 放到 (本地歌单按钮) 下方

    _left_menu.attach_next_to(&_button_play, Some(&_button_local), PositionType::Bottom, 1, 1);// 将 (本地视频按钮) 放到 (本地音频按钮) 下方





    // 引入 css 样式文件
   let provider_bei_jing = CssProvider::new();// 创建 背景 css 提供者

    provider_bei_jing.load_from_data(include_str!("css/bei_jing.css"));// 引入 背景 css 文件
    
    let provider_an_niu = CssProvider::new();// 创建 按钮 css 提供者

    provider_an_niu.load_from_data(include_str!("css/an_niu.css"));// 引入 按钮 css 文件

    let provider_an_niu_biao_qian = CssProvider::new();// 创建 按钮标签 css 提供者

    provider_an_niu_biao_qian.load_from_data(include_str!("css/an_niu_biao_qian.css"));// 引入 按钮标签 css 文件

    let provider_wen_ben_kuang = CssProvider::new();// 创建 文字框 css 提供者

    provider_wen_ben_kuang.load_from_data(include_str!("css/wen_ben_kuang.css"));// 引入 文字框 css 文件

    // 添加 CSS 提供者 到 窗口 
    style_context_add_provider_for_display(// 添加 背景 css 提供者 到 窗口 
        &prelude::WidgetExt::display(&window),
        &provider_bei_jing,
        STYLE_PROVIDER_PRIORITY_APPLICATION,
    );
    
    style_context_add_provider_for_display(// 添加 按钮 css 提供者 到 窗口 
        &prelude::WidgetExt::display(&window),
        &provider_an_niu,
        STYLE_PROVIDER_PRIORITY_APPLICATION,
    );

    style_context_add_provider_for_display(// 添加 按钮标签 css 提供者 到 窗口 
        &prelude::WidgetExt::display(&window),
        &provider_an_niu_biao_qian,
        STYLE_PROVIDER_PRIORITY_APPLICATION,
    );

    style_context_add_provider_for_display(// 添加 文字框 css 提供者 到 窗口 
        &prelude::WidgetExt::display(&window),
        &provider_wen_ben_kuang,
        STYLE_PROVIDER_PRIORITY_APPLICATION,
    );

    // 返回窗口
    window
}