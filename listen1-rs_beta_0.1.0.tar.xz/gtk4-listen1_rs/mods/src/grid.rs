/*
    grid(布局) 模块的实现
*/ 

// 导入必要的库
use gtk4::Grid;
use gtk4::prelude::GridExt;
use gtk4::BaselinePosition;
use gtk4::Align;
use gtk4::prelude::WidgetExt;


// 创建 Grid 布局方法
pub fn grid() -> Grid {
    // 创建 Grid 布局实例
    let grid = Grid::new();

    // 设置 Grid 布局的属性

    // 设置 grid 宽高
    grid.set_size_request(1200, 900); // 设置 Grid 布局的宽高

    // 行列间距
    grid.set_row_spacing(10); // 设置 Grid 布局的行间距

    grid.set_column_spacing(10); // 设置 Grid 布局的列间距

    // 行列等宽等高
    grid.set_row_homogeneous(true); // 设置 Grid 布局的行等宽
    grid.set_column_homogeneous(true); // 设置 Grid 布局的列等高
    
    // 组件布局 在 activate 模块中实现

    // 组件对其
    grid.set_row_baseline_position(0,BaselinePosition::Top); // 设置 第 0 行的基线对齐方式为顶部对齐

    // 组件边距
    grid.set_margin_top(150); // 设置 顶部边距 为 10px
    grid.set_margin_bottom(10); // 设置 底部边距 为 10px
    grid.set_margin_start(10); // 设置 左侧边距 为 10px
    grid.set_margin_end(10); // 设置 右侧边距 为 10px

    // 组件扩展
    grid.set_hexpand(true); // 启用组件的水平扩展
    grid.set_vexpand(true); // 启用组件的垂直扩展

    // grid 布局位置
    grid.set_halign(Align::Start); // 水平对齐位置 (Start End Center ; 左 右 中)
    grid.set_valign(Align::Start); // 垂直对齐位置 (Start End Center ; 上 下 中)
    /*
        将 Align 的 跟随属性改为 End 即可 实现 (水平 右 对齐 ; 垂直 下 对齐)
    */ 

    // 返回 Grid 布局实例
    grid
}

// 父容器 方法
pub fn grid_docker() -> Grid {
    // 创建 实例 继承 grid 方法 的 属性
    let grid = grid(); // 继承 grid() 方法的属性

    // 修改需要调整的属性
   grid.set_margin_top(15); // 设置 顶部边距 为 10px
   grid.set_hexpand(false); // 启用组件的水平扩展
    grid.set_vexpand(false); // 启用组件的垂直扩展
    grid.set_row_homogeneous(false); // 设置 Grid 布局的行等宽
    grid.set_column_homogeneous(false); // 设置 Grid 布局的列等高
    grid.set_row_homogeneous(false); // 设置 Grid 布局的行等宽
    grid.set_column_homogeneous(false); // 设置 Grid 布局的列等高

    // 返回 Grid 布局实例
    grid
}

// 父容器  右侧 菜单栏 
pub fn grid_right_menu() -> Grid {
    // 创建 实例 继承 grid 方法 的 属性
    let grid = grid(); // 继承 grid() 方法的属性

    // 修改需要调整的属性
    grid.set_size_request(900, 900); // 设置 Grid 布局的宽高
    grid.set_margin_top(5); // 设置 顶部边距 为 5px
    grid.set_margin_bottom(5); // 设置 底部边距 为 5px
    grid.set_margin_start(5); // 设置 左侧边距 为 5px
    grid.set_margin_end(5); // 设置 右侧边距 为 5px
    grid.set_hexpand(false); // 启用组件的水平扩展
    grid.set_vexpand(false); // 启用组件的垂直扩展
    grid.set_row_homogeneous(false); // 设置 Grid 布局的行等宽
    grid.set_column_homogeneous(false); // 设置 Grid 布局的列等高
    
    
    // 返回 Grid 布局实例
    grid
}

// 父容器  左侧 选项栏
pub fn grid_left_menu() -> Grid {
    // 创建 实例 继承 grid 方法 的 属性
    let grid = grid(); // 继承 grid() 方法的属性

    // 修改需要调整的属性
    grid.set_size_request(200, 900); // 设置 Grid 布局的宽高
    grid.set_margin_top(5); // 设置 顶部边距 为 5px
    grid.set_margin_bottom(5); // 设置 底部边距 为 5px
    grid.set_margin_start(5); // 设置 左侧边距 为 5px
    grid.set_margin_end(5); // 设置 右侧边距 为 5px
    grid.set_row_homogeneous(false); // 设置 Grid 布局的行等宽
    grid.set_column_homogeneous(false); // 设置 Grid 布局的列等高
    grid.set_halign(Align::Center); // 水平对齐位置 (Start End Center ; 左 右 中)

    // 返回 Grid 布局实例
    grid
}