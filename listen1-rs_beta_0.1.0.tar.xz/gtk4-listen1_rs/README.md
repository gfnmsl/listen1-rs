<!-- 本项目的 灵感 来自 listen1 项目，感谢 listen1 的作者 原项目仓库 https://github.com/listen1/listen1_desktop  -->

<!-- 本 项目 使用到的所有 依赖 会在本 文档 列出 -->

# 开发环境

- 操作系统:arch linux
- 开发工具:rustup (rust 包管理器)
- 编辑器:Visual Studio Code

# 项目依赖

rust 1.85.0 (rust 版本)

gtk4-rs 0.9.6 (gtk4 的 rust 绑定库)
